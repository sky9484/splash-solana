import { useState } from 'react'
import { Btn, Card, Check, Note, Tag } from './shared'
import logo from './assets/logo.webp'
import bot from './assets/bot.webp'

const STATIONS = ['Approved', 'Sent', 'With partner', 'Paid to bank', 'Recording proof', 'Proof recorded']
const TIMES = ['18 Oct, 01:38:06', '01:38:09', '01:38:12', '01:38:14', '01:38:15', '01:38:21']

function Sidebar() {
  return (
    <aside className="t5side" style={{ width: 200, flex: '0 0 200px', background: 'linear-gradient(165deg,#245563,#143c47 55%,#0c3039)', color: '#fffaf1', padding: 16, display: 'flex', flexDirection: 'column', gap: 4, borderRadius: '0 0 0 0' }}>
      <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 14 }}><span style={{ width: 34, height: 34, display: 'grid', placeItems: 'center', background: '#FFFAF4', borderRadius: 10 }}><img src={logo} alt="" width={24} /></span><strong style={{ fontSize: 17 }}>Splash.</strong></div>
      {[['Overview'], ['Pay', 'h'], ['Transfer', 'on'], ['Invoices'], ['Batch payout'], ['Money', 'h'], ['Balance'], ['Treasury'], ['History'], ['Contacts', 'h'], ['Recipients'], ['Control', 'h'], ['Zeke']].map(([t, k]) => k === 'h' ? <div key={t} style={{ fontSize: 10.5, fontWeight: 800, opacity: .6, margin: '10px 0 2px', letterSpacing: '.04em' }}>{t}</div> : <div key={t} style={{ padding: '7px 10px', fontSize: 13, fontWeight: 600, borderRadius: 10, background: k === 'on' ? '#fffaf4' : 'transparent', color: k === 'on' ? '#0c3e48' : undefined }}>{t}</div>)}
    </aside>
  )
}

export default function Track() {
  const [verified, setVerified] = useState(false)
  const [share, setShare] = useState(false)
  const [dest, setDest] = useState('myinvois')
  const [country, setCountry] = useState<'MY' | 'PH' | 'ID' | 'OTHER'>('MY')
  const DEST = {
    MY: { name: 'Malaysia · LHDN MyInvois', opt: 'Send to MyInvois as a self-billed e-Invoice', note: 'A Malaysian buyer paying a foreign supplier issues a self-billed e-Invoice. Splash fills what the receipt knows (amounts, rate, references, dates); you confirm the supplier’s TIN and classification before it goes.' },
    PH: { name: 'Philippines · BIR EIS', opt: 'Send to the BIR e-Invoicing System', note: 'For Philippine companies in the EIS rollout. Splash prepares the sales/receipt data; your accountant submits from your BIR account.' },
    ID: { name: 'Indonesia · Coretax', opt: 'Prepare for Coretax (e-Faktur)', note: 'Splash exports the fields Coretax asks for; your tax officer uploads them.' },
    OTHER: { name: 'Not in a covered corridor', opt: 'Compile the PDF and a verify link', note: 'Splash compiles the receipt, invoice copy and proof into one PDF and gives you a link the auditor can open and verify.' },
  }[country]
  return (
    <div className="stage" style={{ display: 'flex', minHeight: '100vh' }}>
      <Sidebar />
      <main style={{ flex: 1, minWidth: 0, maxWidth: '100%', padding: '22px 24px 60px', overflow: 'hidden' }}>
        <Note><strong>Step 5 after the payment.</strong> Same dark intent header; the receipt is a document: who, what, when, proof. “Download PDF” produces tab 5. <strong>“Share with auditor”</strong> now opens a sheet (click it): Splash reads the company’s registration country and offers the right destination: MyInvois for Malaysia, BIR EIS for the Philippines, Coretax for Indonesia; anywhere else gets the PDF and a verify link. The tax-portal sends are <em>planned</em>: each needs onboarding to that portal’s API, so prompt 12 builds the sheet and the PDF/link path first.</Note>
        <div className="txhead" style={{ marginTop: 16, minWidth: 0 }}>
          <div className="txhead-top">
            <div>
              <div style={{ display: 'flex', gap: 6, marginBottom: 8, flexWrap: 'wrap' }}><span className="hchip">Transfer</span><span className="hchip">Paid</span><span className="hchip" style={{ background: 'var(--gold)', color: 'var(--deep)', borderColor: 'var(--gold)' }}>Test mode</span></div>
              <div style={{ fontSize: 24, fontWeight: 800, letterSpacing: '-.02em' }}>Pay Jojong Trading</div>
              <div style={{ fontSize: 13, color: 'var(--on-cyan-2)', marginTop: 4 }}>UnionBank •••• 9000 · Philippines · invoice 10000</div>
            </div>
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, fontWeight: 700, color: 'var(--on-cyan-2)' }}><span>Step 5 of 5</span><span>Track</span></div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5,1fr)', gap: 4, marginTop: 8 }}>{['Recipient', 'Amount', 'Route', 'Approve', 'Track'].map((s, i) => <div key={s}><div style={{ height: 5, borderRadius: 5, background: i < 4 ? 'var(--mint)' : 'var(--coral)' }} /><div style={{ fontSize: 11, fontWeight: 700, marginTop: 5 }}>{s}</div></div>)}</div>
            </div>
          </div>
          <div className="txhead-metrics num">{[['They receive', '₱780,000.00'], ['You paid', 'US$13,629.67'], ['Paid out by', 'PESONet'], ['Quote', 'Locked at 57.40']].map(([k, v]) => <div key={k}><div className="lbl" style={{ color: 'var(--on-cyan-2)' }}>{k}</div><div style={{ fontSize: 15, fontWeight: 800, marginTop: 2 }}>{v}</div></div>)}</div>
        </div>

        <div className="t5grid" style={{ display: 'grid', gridTemplateColumns: 'minmax(0,1fr) 320px', gap: 16, marginTop: 16, alignItems: 'start' }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <Card title="Paid, with proof recorded" right={<Tag tone="ok"><Check size={10} /> Proof recorded</Tag>}>
              <ol className="track">{STATIONS.map((s, i) => <li key={s} className="st"><span className="sdot"><Check size={11} /></span><span>{s}</span><span style={{ fontSize: 11, fontWeight: 500, color: 'var(--muted)' }}>{TIMES[i]}</span>{i < 5 && <span className="sbar" />}</li>)}</ol>
              <p style={{ fontSize: 12.5, color: 'var(--muted)', marginTop: 10 }}>In this demo the payout partner is a test partner. This page updates by itself.</p>
            </Card>

            {/* THE RECEIPT, as a document */}
            <div className="doc">
              <div className="doc-head">
                <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
                  <span style={{ width: 44, height: 44, borderRadius: 12, background: 'var(--cyan)', display: 'grid', placeItems: 'center' }}><img src={logo} alt="" width={26} style={{ filter: 'brightness(0) invert(1)' }} /></span>
                  <div><div className="lbl">Receipt</div><div style={{ fontSize: 20, fontWeight: 900, color: 'var(--deep)', letterSpacing: '-.02em' }}>SPL-R-20261018-6512</div><div style={{ fontSize: 12.5, color: 'var(--muted)' }}>Acme Manufacturing paid Jojong Trading · 18 Oct 2026</div></div>
                </div>
                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}><Btn kind="quiet" onClick={() => setVerified(true)}>{verified ? <><Check size={12} /> Verified</> : '◎ Verify receipt'}</Btn><Btn kind="quiet">⤓ Download PDF</Btn><Btn kind="primary" onClick={() => setShare(true)}>Share with auditor</Btn></div>
              </div>
              <div className="doc-body">
                <div>
                  <div className="lbl" style={{ margin: '4px 0 2px' }}>Who</div>
                  <div className="kv"><span>Paid to</span><strong>Jojong Trading<br /><span style={{ fontWeight: 500, color: 'var(--muted)' }}>UnionBank •••• 9000 · Philippines · verified by call-back 14 Oct</span></strong></div>
                  <div className="kv"><span>Paid from</span><strong>Acme Manufacturing · Payments account</strong></div>
                  <div className="kv"><span>Approved by</span><strong>Demo Operator, on a device · key 6vTL…w9Ad</strong></div>
                  <div className="kv"><span>Drafted by</span><strong>Zeke, from invoice 10000</strong></div>
                </div>
                <div>
                  <div className="lbl" style={{ margin: '4px 0 2px' }}>What</div>
                  <div className="kv num"><span>They received</span><strong style={{ fontSize: 17 }}>₱780,000.00</strong></div>
                  <div className="kv num"><span>You paid</span><strong>US$13,629.67 <span style={{ fontWeight: 500, color: 'var(--muted)' }}>· fee US$34.07 (0.25%) included</span></strong></div>
                  <div className="kv num"><span>Rate</span><strong>1 USD = 57.40 PHP · test rate · locked 01:37:52</strong></div>
                  <div className="kv"><span>Route</span><strong>Cheapest · paid out by PESONet</strong></div>
                  <div className="kv"><span>Bank reference</span><strong className="mono" style={{ fontSize: 12.5 }}>MOCK-PESONET-20261017-6512F659</strong></div>
                </div>
              </div>
              <div className="proofbox">
                <span style={{ fontSize: 20 }}>{verified ? '✓' : '◎'}</span>
                <div style={{ flex: 1 }}>
                  <strong>{verified ? 'This receipt verifies. It matches the proof recorded for it.' : 'Proof recorded. Verify to check nothing was changed since.'}</strong>
                  <div className="mono" style={{ fontSize: 11.5, marginTop: 4, opacity: .85 }}>fingerprint 4108…534c · root 0x7c1e…a04b · recorded 18 Oct 2026, 01:38:21 · test network</div>
                  <div style={{ fontSize: 12.5, marginTop: 6 }}>Five checks run in your browser. The server supplies the record, not the answer.</div>
                </div>
                {!verified && <Btn kind="dark" onClick={() => setVerified(true)}>Verify now</Btn>}
              </div>
              <div style={{ padding: '4px 24px 18px', display: 'flex', gap: 16, fontSize: 13, fontWeight: 700, color: 'var(--teal)' }}><span>Full receipt ›</span><span>Technical details ›</span><span>Download evidence pack (ZIP) ›</span></div>
            </div>
          </div>

          <aside style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <Card title="What happened">
              {STATIONS.map((s, i) => <div key={s} style={{ display: 'grid', gridTemplateColumns: '10px 1fr auto', gap: 10, padding: '6px 0', fontSize: 13 }}><span style={{ width: 8, height: 8, borderRadius: 99, background: 'var(--teal)', marginTop: 6 }} /><strong>{s}</strong><span className="num" style={{ color: 'var(--muted)', fontSize: 12 }}>{TIMES[i].replace('18 Oct, ', '')}</span></div>)}
            </Card>
            <Card title="What’s next">
              <p style={{ fontSize: 13.5, color: 'var(--text-2)', lineHeight: 1.5 }}>Invoice 10000 is marked paid. The receipt is ready to verify and share.</p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 12 }}><Btn kind="quiet">Save as template</Btn><Btn kind="quiet">Pay Jojong Trading again</Btn><Btn kind="primary">Start a new transfer</Btn></div>
            </Card>
            <Card style={{ background: 'var(--cyan)', color: 'var(--on-cyan)', border: 0 }}>
              <div style={{ display: 'flex', gap: 10 }}><img src={bot} alt="" width={34} height={34} style={{ background: '#fffaf4', borderRadius: 8, padding: 2, flex: '0 0 34px' }} /><p style={{ fontSize: 13, lineHeight: 1.5 }}><strong>Zeke:</strong> Your accountant usually wants the PDF and the invoice together. Want me to draft the email with both attached? You send it.</p></div>
            </Card>
          </aside>
        </div>
        {share && (
          <div className="sheet-bg" style={{ position: 'fixed', borderRadius: 0 }} onClick={() => setShare(false)}>
            <div className="sheet" role="dialog" aria-label="Share with auditor" onClick={e => e.stopPropagation()}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}><strong style={{ fontSize: 18, color: 'var(--deep)' }}>Share with auditor</strong><button type="button" aria-label="Close" onClick={() => setShare(false)} style={{ border: 0, background: 'transparent', fontSize: 22, cursor: 'pointer', width: 36, height: 36 }}>×</button></div>
              <div className="card" style={{ padding: '12px 14px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10 }}>
                <div><div className="lbl">Detected from your company registration</div><strong style={{ fontSize: 14, color: 'var(--deep)' }}>{DEST.name}</strong></div>
                <select aria-label="Preview another country" value={country} onChange={e => setCountry(e.target.value as 'MY')} style={{ font: 'inherit', fontSize: 12.5, borderRadius: 30, padding: '6px 10px', border: '1px solid var(--line)', background: '#fff' }}><option value="MY">Malaysia</option><option value="PH">Philippines</option><option value="ID">Indonesia</option><option value="OTHER">Other</option></select>
              </div>
              <div role="radiogroup" aria-label="Destination" style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {country !== 'OTHER' && <button type="button" role="radio" className="opt" aria-checked={dest === 'myinvois'} onClick={() => setDest('myinvois')}><span style={{ fontSize: 18 }}>🏛️</span><div><b>{DEST.opt} <Tag tone="gold">Planned</Tag></b><span>{DEST.note}</span></div></button>}
                <button type="button" role="radio" className="opt" aria-checked={dest === 'link'} onClick={() => setDest('link')}><span style={{ fontSize: 18 }}>🔗</span><div><b>Send a verify link by email</b><span>The auditor opens the read-only receipt and runs Verify in their browser. The link works for 90 days.</span></div></button>
                <button type="button" role="radio" className="opt" aria-checked={dest === 'pack'} onClick={() => setDest('pack')}><span style={{ fontSize: 18 }}>🗂️</span><div><b>Download the evidence pack</b><span>receipt.pdf, the invoice copy, approvals.json, proof.json and a README on verifying offline.</span></div></button>
              </div>
              {dest === 'link' && <div className="field"><label>Auditor’s email</label><div className="in">auditor@firm.example</div></div>}
              <div style={{ display: 'flex', gap: 8, marginTop: 'auto' }}><Btn kind="primary" lg style={{ flex: 1 }}>{dest === 'myinvois' ? 'Prepare the e-Invoice' : dest === 'link' ? 'Send the link' : 'Download ZIP'}</Btn><Btn kind="quiet" lg onClick={() => setShare(false)}>Cancel</Btn></div>
              <p style={{ fontSize: 11.5, color: 'var(--muted)' }}>Nothing leaves Splash without this confirmation. Every share is logged on the receipt.</p>
            </div>
          </div>
        )}
      </main>
    </div>
  )
}
