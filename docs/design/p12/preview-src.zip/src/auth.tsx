import { useEffect, useState } from 'react'
import { Btn, Check, Field, Note, Tag, Wordmark } from './shared'
import gB from './assets/g_bn.webp'
import gC from './assets/g_c.webp'
import gD from './assets/g_d.webp'

const ART: Record<string, string> = { B: gB, C: gC, D: gD }
import logo from './assets/logo.webp'
import drop from './assets/drop.webp'
import usd from './assets/usd.webp'

const PAGES = {
  login: { kick: 'Business workspace', h: 'Sign in to Splash', sub: 'Your approvals are signed on this device. Splash never holds your keys.', art: ['B', ''], lead: ['Every payment, one record', 'Invoice, approval, transfer and rate, kept together for the auditor.'], form: 'login' },
  signup: { kick: 'Open a business account', h: 'Build your payment desk', sub: 'Create your workspace, then complete KYB to activate payouts.', art: ['C', ''], lead: ['Your own account, from day one', 'Keys made in your browser. Nobody at Splash can move the money.'], form: 'signup' },
  forgot: { kick: 'Account recovery', h: 'Reset your password', sub: 'Enter your business email and we will send a link to choose a new password.', art: ['D', ''], lead: ['Recover access', 'The password opens the desk. The vault stays locked until you approve on your device.'], form: 'forgot' },
} as const

export default function Auth() {
  const [page, setPage] = useState<keyof typeof PAGES>('login')
  const [tick, setTick] = useState(0)
  useEffect(() => { const i = setInterval(() => setTick(t => t + 1), 1600); return () => clearInterval(i) }, [])
  const p = PAGES[page]
  const status = ['Opening your desk', 'Checking who can approve', 'Fetching what needs you', 'Ready'][tick % 4]
  return (
    <div className="stage pad">
      <div className="wrap" style={{ maxWidth: 1180 }}>
        <Note><strong>Sign in, sign up and forgot password.</strong> Pale page, one white 30 px card, a solid cyan art panel with its own image (B, C, D, your generated images, none shared with the landing or dashboard), 30 px fields, 48 px button, no all-caps labels. Below: the loading screen.</Note>
        <div style={{ display: 'flex', gap: 6, margin: '16px 0', flexWrap: 'wrap' }}>{(Object.keys(PAGES) as (keyof typeof PAGES)[]).map(k => <button key={k} type="button" className={`btn ${page === k ? 'dark' : 'quiet'}`} onClick={() => setPage(k)}>{PAGES[k].h}</button>)}</div>

        <div className="auth" style={{ minHeight: 0, padding: 0 }}>
          <div className="auth-card">
            <div className={`auth-art ${page === 'login' ? 'night' : ''}`}>
              <div><Wordmark light /><div style={{ fontSize: 12, color: 'var(--on-cyan-2)', marginTop: 4 }}>Pay suppliers abroad. Prove every payment.</div></div>
              <div style={{ margin: '24px 0' }}><img src={ART[p.art[0]]} alt="" className="auth-img" key={p.art[0]} /></div>
              <div>
                <div className="kick" style={{ color: 'var(--on-cyan-2)' }}>{p.lead[0]}</div>
                <p style={{ fontSize: 20, fontWeight: 800, lineHeight: 1.25, marginTop: 8, maxWidth: '26ch' }}>{p.lead[1]}</p>
                <div style={{ display: 'flex', gap: 8, marginTop: 14, flexWrap: 'wrap' }}>{['Your vault, your keys', 'A person approves every payment', 'One record per payment'].map(t => <span key={t} style={{ fontSize: 11.5, fontWeight: 700, display: 'inline-flex', gap: 5, alignItems: 'center', color: 'var(--on-cyan-2)' }}><span style={{ color: 'var(--gold)' }}><Check size={11} /></span>{t}</span>)}</div>
              </div>
            </div>
            <div className="auth-form">
              <span className="kick">{p.kick}</span>
              <h1>{p.h}</h1>
              <p style={{ fontSize: 14, color: 'var(--text-2)', lineHeight: 1.5 }}>{p.sub}</p>
              {p.form === 'signup' && <div className="g2" style={{ gap: 12 }}><Field label="Company name" ph="Selangor Trading Sdn Bhd" /><Field label="Primary market" ph="Malaysia ▾" /></div>}
              <Field label="Business email" ph="name@company.com" icon="✉" />
              {p.form !== 'forgot' && <Field label={p.form === 'signup' ? 'Create password' : 'Password'} ph={p.form === 'signup' ? '12+ characters with a letter and a number' : 'Enter your password'} icon="🔒" />}
              {p.form === 'login' && <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13 }}><label><input type="checkbox" defaultChecked /> Keep me signed in for 30 days</label><a style={{ color: 'var(--teal)', fontWeight: 700 }}>Forgot password?</a></div>}
              {p.form === 'signup' && <label style={{ fontSize: 12.5, color: 'var(--text-2)' }}><input type="checkbox" /> I agree to the Splash terms and confirm I am authorised to register this business.</label>}
              <Btn kind="primary" lg>{p.form === 'login' ? 'Sign in →' : p.form === 'signup' ? 'Create business workspace →' : 'Email me a reset link →'}</Btn>
              {p.form === 'signup' && <div className="card" style={{ padding: '12px 16px', background: 'var(--gold-fill)', fontSize: 12.5 }}><strong>What happens next:</strong> 1. Confirm your email · 2. Complete KYB · 3. Add test money and send a first payout</div>}
              {p.form === 'forgot' && <div className="card" style={{ padding: '12px 16px', background: 'var(--gold-fill)', fontSize: 12.5 }}><strong>No email after a few minutes?</strong> Check spam, then request another link. Links work once and for 30 minutes.</div>}
              <p style={{ fontSize: 13, color: 'var(--muted)' }}>{p.form === 'login' ? <>New to Splash? <a style={{ color: 'var(--teal)', fontWeight: 700 }}>Create a business account</a></> : <>Already have an account? <a style={{ color: 'var(--teal)', fontWeight: 700 }}>Sign in</a></>}</p>
            </div>
          </div>
        </div>

        <h2 style={{ fontSize: 20, fontWeight: 800, color: 'var(--on-page)', margin: '36px 0 10px' }}>Loading screen</h2>
        <div className="g2">
          <div className="loader" style={{ background: 'linear-gradient(180deg,var(--page),var(--page-2))', border: '1px solid var(--line)' }}>
            <div className="loader-in">
              <div className="loader-card riseIn">
                <div style={{ position: 'relative', width: 96, height: 96 }}>
                  <img src={drop} alt="" className="bob drop" />
                  <img src={usd} alt="" width={30} style={{ position: 'absolute', right: -8, bottom: 6, animation: 'bob 2.6s ease-in-out infinite', animationDelay: '.8s' }} />
                </div>
                <div style={{ fontWeight: 900, fontSize: 20, color: 'var(--deep)', letterSpacing: '-.02em', display: 'flex', alignItems: 'center', gap: 8 }}><img src={logo} alt="" width={22} /> Splash</div>
                <div className="lwire" aria-hidden><span className="coin" style={{ top: -8, width: 16, height: 16 }} /></div>
                <div className="lstatus" aria-live="polite">{status}{tick % 4 === 3 ? '' : '…'}</div>
                <div className="ldots" aria-hidden><i /><i /><i /></div>
              </div>
              <div style={{ fontSize: 12, color: 'var(--on-page-2)' }}>Test mode · no real money moves</div>
            </div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div className="card"><h3 className="card-title">What changed</h3><p style={{ fontSize: 13.5, lineHeight: 1.55, color: 'var(--text-2)' }}>Today: the droplet on ripple rings with a shimmer bar and “Preparing your desk”, on the old grid. New: the same droplet (it’s the brand), now on a floating white card like every other box, one gold coin travelling a short wire from “you” to the bank, and a status line that says what is actually loading. The wire is the dashboard’s own route motif, so the loader teaches the product while it waits.</p></div>
            <div className="card"><h3 className="card-title">Rules</h3><ul style={{ margin: 0, paddingLeft: 18, fontSize: 13.5, lineHeight: 1.6, color: 'var(--text-2)' }}><li>No percent, no fake progress. The status line is driven by the real steps (session, approvers, needs-you).</li><li>Shows only after 300 ms, so quick loads never flash it.</li><li>Reduced motion: coin and dots stop; the status line still updates.</li><li>Same component inside the dashboard (route changes) and on first open.</li></ul></div>
            <div className="card" style={{ background: 'var(--gold-fill)' }}><Tag tone="gold">Images B, C, D</Tag><p style={{ fontSize: 13, marginTop: 8, color: 'var(--gold-ink)' }}>Sign in uses your night image (B night): the panel takes the image’s own deep-night colour so the picture has no edge. Sign up and forgot sit straight on the cyan panel. Prompts stay in tab 6 if you want to regenerate one.</p></div>
          </div>
        </div>
      </div>
    </div>
  )
}
