import { useState } from 'react'
import { Btn, Card, Footer, Note, Row, Tag, Wordmark } from './shared'
import wcr1 from './assets/wcr1.webp'
import wcr2 from './assets/wcr2.webp'
import wcr3 from './assets/wcr3.webp'
import wcd1 from './assets/wcd1.webp'
import wcd2 from './assets/wcd2.webp'
import wcd3 from './assets/wcd3.webp'
import loopsettle from './assets/loopsettle.webp'
import loopsupply from './assets/loopsupply.webp'
import loopsave from './assets/loopsave.webp'

const Head = ({ eyebrow, title, em, lede }: { eyebrow: string; title: string; em: string; lede: string }) => (
  <div className="sec-head" style={{ alignItems: 'end' }}>
    <div><span className="eyebrow">{eyebrow}</span><h2 className="h-clean" style={{ marginTop: 12 }}>{title} <em>{em}</em></h2></div>
    <p className="lede">{lede}</p>
  </div>
)
const Trio = ({ items }: { items: [string, string, string, string, string][] }) => (
  <div className="g3">{items.map(([n, t, d, art, foot]) => (
    <Card key={n} hov><span className="eyebrow" style={{ fontSize: 12 }}>{n}</span><div className="art-box"><img src={art} alt="" /></div><h3 style={{ fontSize: 19, fontWeight: 800, color: 'var(--deep)', letterSpacing: '-.02em' }}>{t}</h3><p style={{ fontSize: 13.5, lineHeight: 1.55, color: 'var(--text-2)', margin: '8px 0 12px' }}>{d}</p><Tag>{foot}</Tag></Card>
  ))}</div>
)

export default function WorkingCapital() {
  const [early, setEarly] = useState(true)
  return (
    <div className="stage">
      <div className="wrap topnav"><Wordmark /><div style={{ display: 'flex', gap: 8 }}><Btn kind="quiet">← Back to Splash</Btn><Btn kind="dark">Start sending →</Btn></div></div>
      <div className="wrap"><Note><strong>Fintech standard, clear and modern.</strong> No extruded or outlined type on this page: headings are plain Geist 800 in sentence case, the accent word in teal, eyebrows as short labels. Same boxes and cyan blocks as the dashboard. The extruded display type stays only on the landing hero and the footer.</Note></div>

      <section className="sec wrap" style={{ paddingTop: 36 }}>
        <div className="cyan" style={{ padding: 36 }}>
          <div className="sec-head" style={{ marginBottom: 0, alignItems: 'center' }}>
            <div>
              <div style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}><span className="eyebrow">Supply loop · roadmap</span><Tag tone="coral">Coming capability · subject to licensing</Tag></div>
              <h1 className="h-clean" style={{ margin: '14px 0 16px', fontSize: 'clamp(36px,4.8vw,64px)' }}>Your invoices are <em>working capital.</em></h1>
              <p className="lede" style={{ color: 'var(--on-cyan-2)' }}>Splash is building buyer-funded early payment on the same settlement rail that moves your payouts today. No third-party lender: your buyer’s approved US dollars, released early against an invoice you both already trust.</p>
              <div style={{ display: 'flex', gap: 10, margin: '20px 0 22px', flexWrap: 'wrap' }}><Btn kind="gold" lg>Register financing interest →</Btn><Btn kind="ghost" lg>See live settlement first</Btn></div>
              <div className="g3" style={{ gap: 10 }}>{[['Funded by', 'The buyer, not a lender'], ['Rail', 'Same one payouts use'], ['Control', 'Approval-gated, human-final']].map(([k, v]) => <div key={k}><div className="lbl" style={{ color: 'var(--on-cyan-2)' }}>{k}</div><strong style={{ fontSize: 13.5 }}>{v}</strong></div>)}</div>
            </div>
            <div className="card" style={{ padding: 22 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}><Tag tone="teal">Receivable</Tag><span style={{ fontSize: 12, color: 'var(--muted)', fontWeight: 700 }}>INV-4471 · net 90</span></div>
              <div className="lbl" style={{ marginTop: 14 }}>Invoice face value</div>
              <div className="fig num" style={{ fontSize: 46, margin: '4px 0 14px' }}>US$100,000</div>
              <div style={{ display: 'flex', padding: 3, background: 'rgb(12 62 72 / .08)', borderRadius: 30 }}>
                {[['Hold to maturity', false], ['Take early payment', true]].map(([t, v]) => <button key={String(t)} type="button" aria-pressed={early === v} onClick={() => setEarly(v as boolean)} style={{ flex: 1, border: 0, minHeight: 40, borderRadius: 30, fontWeight: 700, fontSize: 13, cursor: 'pointer', background: early === v ? '#fff' : 'transparent', color: 'var(--deep)', boxShadow: early === v ? 'var(--lift-1)' : 'none' }}>{t}</button>)}
              </div>
              <div style={{ marginTop: 10 }}><Row k="Settles" v={early ? 'Today · same rail' : 'In 90 days'} /><Row k="Supplier receives" v={early ? 'US$98,800' : 'US$100,000'} /><Row k="Discount" v={early ? '1.2% · US$1,200' : '—'} /></div>
              <div className="card" style={{ padding: '10px 14px', marginTop: 10, background: 'var(--coral-fill)', fontSize: 12.5, color: 'var(--coral-ink)' }}>{early ? 'Buyer saves (illustrative) US$1,200 on idle US dollars held about 90 days, about 4.9% a year.' : 'Nothing changes. The invoice settles on its due date on the same rail.'}</div>
              <div style={{ display: 'flex', gap: 6, marginTop: 12, flexWrap: 'wrap' }}>{['Buyer-funded', 'No lender', 'Approval-gated', 'Illustrative'].map(t => <Tag key={t}>{t}</Tag>)}</div>
            </div>
          </div>
        </div>
      </section>

      <section className="sec wrap" style={{ paddingTop: 24 }}>
        <Head eyebrow="01 · The receivable" title="An invoice that carries" em="its own settlement history." lede="A Receivable would be an invoice object that remembers how it gets paid: who approved it, on what rail, with what proof. History a lender would charge you to underwrite, your buyer can simply read." />
        <Trio items={[['Verified', 'Issued between verified businesses.', 'A Receivable would only exist between two KYB-verified counterparties already transacting on Splash: the same verification that gates every payout today.', wcr1, 'KYB-gated on both sides'], ['History', 'Carries its settlement history.', 'Quotes, approvals, receipts and settlement proof would anchor to the invoice itself: an invoice that shows how reliably it gets paid.', wcr2, 'Record attached'], ['Fundable', 'Safe to pay early.', 'A receivable with a clean, verifiable history is the safest thing to fund early. No guesswork, no external credit file: the record is the underwriting.', wcr3, 'History a buyer can read']]} />
      </section>

      <section className="sec wrap" style={{ paddingTop: 0 }}>
        <Head eyebrow="02 · Buyer-funded discounting" title="Early payment," em="without a lender." lede="Dynamic discounting is a trade between two parties who already trust each other: the buyer puts idle US dollars to work, the supplier turns a due date into cash flow. Splash would only referee the exchange." />
        <Trio items={[['Offer', 'Buyer offers early payment.', 'Your buyer sees an approved 90-day invoice and offers to pay it now, with their own US dollars already on the settlement rail.', wcd1, 'Buyer-initiated'], ['Accept', 'Supplier accepts a discount.', 'You choose per invoice: the full amount on the due date, or a small discount today. No obligation either way.', wcd2, 'Per-invoice choice'], ['Settle', 'Settlement, no lender.', 'The buyer’s own funds would settle the early payment over Splash. No factoring house, no credit line, no lender between you.', wcd3, 'No third-party lender']]} />
      </section>

      <section className="sec wrap" style={{ paddingTop: 0 }}>
        <Head eyebrow="03 · Where Supply fits" title="One rail," em="three loops." lede="Settle is live and feeds the loop with verified counterparties and settlement history. Supply would compound it into working capital. Save keeps idle balances tidy in between." />
        <div className="g3">
          {[['Settle', 'The feeding wedge', true, 'Collect USD, pay Southeast Asia. Every approved payout builds verified counterparties and settlement history.', loopsettle, 'USD → PHP · live on testnet'], ['Supply', 'Working capital', false, 'Invoices would become working capital: your buyer funds early payment against a receivable whose settlement history both sides can verify.', loopsupply, 'Buyer-funded · no third-party lender'], ['Save', 'Balance hygiene', true, 'Idle US dollars follow a projected, variable treasury posture. Your business approves every move.', loopsave, 'Projected · variable · human-approved']].map(([t, k, live, d, art, foot]) => (
            <Card key={String(t)} hov>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}><div><strong style={{ fontSize: 18, color: 'var(--deep)' }}>{t}</strong> <span style={{ fontSize: 12, color: 'var(--muted)', fontWeight: 700 }}>{k}</span></div>{live ? <Tag tone="ok">● Live</Tag> : <Tag tone="coral">Roadmap</Tag>}</div>
              <div className="art-box" style={{ height: 120 }}><img src={art as string} alt="" style={{ maxHeight: 120 }} /></div>
              <p style={{ fontSize: 13.5, lineHeight: 1.55, color: 'var(--text-2)', marginBottom: 10 }}>{d}</p><Tag>{foot}</Tag>
            </Card>
          ))}
        </div>
      </section>

      <section className="sec wrap" style={{ paddingTop: 0 }}>
        <div className="cyan" style={{ padding: 36, display: 'grid', gridTemplateColumns: 'minmax(0,1.4fr) auto', gap: 24, alignItems: 'center' }}>
          <div><span className="eyebrow">Shape the build order</span><h2 className="h-clean" style={{ margin: '12px 0 10px' }}>Early interest decides <em>which corridor is first.</em></h2><p style={{ fontSize: 13.5, color: 'var(--on-cyan-2)', maxWidth: '60ch', lineHeight: 1.5 }}>Dynamic discounting is a coming capability, subject to licensing. Registering interest does not create a financing commitment; it tells us which corridors to build first.</p></div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}><Btn kind="gold" lg>Register financing interest →</Btn><Btn kind="ghost" lg>See live settlement</Btn></div>
        </div>
      </section>
      <Footer />
    </div>
  )
}
