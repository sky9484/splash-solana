import { Card, Note, Tag } from './shared'
import { CANVA, NEGATIVE, PROMPTS, STYLE } from './prompts'

export default function PromptsTab() {
  return (
    <div className="stage pad">
      <div className="wrap" style={{ maxWidth: 1080 }}>
        <Note><strong>Eight images, one style.</strong> Paste the style block first, then one image prompt, then the negative prompt (Grok Imagine takes it in the same box; Gemini as a second line “Avoid: …”). Generate 3–4 variations each and pick the one whose camera matches the existing art. The same text is saved to the project as <span className="mono">image-prompts_landing-auth_2026-10-18.md</span>.</Note>
        <h2 style={{ fontSize: 20, fontWeight: 800, color: 'var(--on-page)', margin: '20px 0 10px' }}>Style block (paste before every prompt)</h2>
        <div className="prompt">{STYLE}</div>
        <h2 style={{ fontSize: 20, fontWeight: 800, color: 'var(--on-page)', margin: '20px 0 10px' }}>Negative prompt (paste after every prompt)</h2>
        <div className="prompt">{NEGATIVE}</div>
        <h2 style={{ fontSize: 20, fontWeight: 800, color: 'var(--on-page)', margin: '26px 0 10px' }}>The eight images</h2>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {PROMPTS.map(p => (
            <Card key={p.id} title={<span><Tag tone="gold">{p.id}</Tag> &nbsp;{p.title}</span>} right={<span style={{ fontSize: 12.5, color: 'var(--muted)' }}>{p.where}</span>}>
              <div className="prompt">{p.body}</div>
            </Card>
          ))}
        </div>
        <h2 style={{ fontSize: 20, fontWeight: 800, color: 'var(--on-page)', margin: '26px 0 10px' }}>After generation, in Canva</h2>
        <div className="prompt">{CANVA}</div>
      </div>
    </div>
  )
}
