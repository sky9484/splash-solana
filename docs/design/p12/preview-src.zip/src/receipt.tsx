import { Note, Tag } from './shared'
import logo from './assets/logo.webp'

export default function Receipt() {
  return (
    <div className="stage pad">
      <div className="wrap" style={{ maxWidth: 1080 }}>
        <Note><strong>The receipt your auditor and accountant get.</strong> One A4 page, printable, the same whether it comes from “Download PDF”, the auditor link or the evidence pack. Top: who paid whom, how much, and a verification seal. Middle: what moved and when. Bottom: the proof, how anyone can check it, and the approvals. Test-mode copies carry a watermark. Amounts are integers from the ledger; nothing is recomputed in the PDF.</Note>
        <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0,1fr) 300px', gap: 20, marginTop: 18, alignItems: 'start' }}>
          <div className="a4-wrap"><article className="a4" aria-label="Payment receipt">
            <div className="seal"><b>VERIFIED</b>proof recorded<br />18 Oct 2026<br />01:38:21 MYT</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}><span style={{ width: 36, height: 36, display: 'grid', placeItems: 'center', background: 'var(--cyan)', borderRadius: 10 }}><img src={logo} alt="" width={22} style={{ filter: 'brightness(0) invert(1)' }} /></span><div><div style={{ fontWeight: 900, fontSize: 17, letterSpacing: '-.02em' }}>Splash</div><div className="mono" style={{ fontSize: 10, color: 'var(--muted)', letterSpacing: '.08em', textTransform: 'uppercase' }}>Payment receipt</div></div></div>
            <h1 style={{ marginTop: 22 }}>Payment receipt</h1>
            <div className="mono" style={{ fontSize: 12, color: 'var(--muted)', marginTop: 4 }}>SPL-R-20261018-6512 · issued 18 Oct 2026 · Test mode: simulated, no real money moved</div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginTop: 26 }}>
              <div className="block"><div className="mono" style={{ fontSize: 10, letterSpacing: '.08em', textTransform: 'uppercase', color: 'var(--muted)' }}>Paid by</div><strong style={{ fontSize: 15, display: 'block', marginTop: 4 }}>Acme Manufacturing Sdn Bhd</strong>Petaling Jaya, Selangor, Malaysia<br />Payments account · ID 86UH…Vp9c</div>
              <div className="block"><div className="mono" style={{ fontSize: 10, letterSpacing: '.08em', textTransform: 'uppercase', color: 'var(--muted)' }}>Paid to</div><strong style={{ fontSize: 15, display: 'block', marginTop: 4 }}>Jojong Trading</strong>UnionBank •••• 9000 · Philippines<br />Bank details verified by call-back, 14 Oct 2026</div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1.3fr 1fr 1fr', gap: 14, marginTop: 14 }}>
              <div className="block" style={{ background: 'var(--cyan)', color: 'var(--on-cyan)' }}><div className="mono" style={{ fontSize: 10, letterSpacing: '.08em', textTransform: 'uppercase', color: 'var(--on-cyan-2)' }}>Supplier received</div><div className="num" style={{ fontSize: 30, fontWeight: 900, letterSpacing: '-.03em', marginTop: 4 }}>₱780,000.00</div><div style={{ fontSize: 11.5, color: 'var(--on-cyan-2)' }}>Philippine pesos, by PESONet · ref MOCK-PESONET-20261017-6512F659</div></div>
              <div className="block"><div className="mono" style={{ fontSize: 10, letterSpacing: '.08em', textTransform: 'uppercase', color: 'var(--muted)' }}>You paid</div><div className="num" style={{ fontSize: 22, fontWeight: 900, marginTop: 4 }}>US$13,629.67</div><div style={{ fontSize: 11.5, color: 'var(--muted)' }}>US$13,595.60 converted + US$34.07 fee (0.25%)</div></div>
              <div className="block"><div className="mono" style={{ fontSize: 10, letterSpacing: '.08em', textTransform: 'uppercase', color: 'var(--muted)' }}>Rate</div><div className="num" style={{ fontSize: 22, fontWeight: 900, marginTop: 4 }}>57.40</div><div style={{ fontSize: 11.5, color: 'var(--muted)' }}>PHP per US$ · test rate · locked 01:37:52</div></div>
            </div>

            <table style={{ marginTop: 26 }}>
              <thead><tr><th>Reference</th><th>Detail</th><th>Reference</th><th>Detail</th></tr></thead>
              <tbody>
                <tr><td>Supplier invoice</td><td className="mono">10000</td><td>Purchase order</td><td className="mono">PO-1201</td></tr>
                <tr><td>Purpose</td><td>Goods: pallets and stretch film</td><td>Route</td><td>Cheapest · partner’s lower-cost lane</td></tr>
                <tr><td>Splash payment id</td><td className="mono">pay_cf689d51319917ab</td><td>Approver</td><td>Demo Operator (owner), device key 6vTL…w9Ad</td></tr>
              </tbody>
            </table>

            <table style={{ marginTop: 22 }}>
              <thead><tr><th>Event</th><th>Time (MYT)</th><th>By</th><th>Evidence</th></tr></thead>
              <tbody>
                {[['Invoice read and payment drafted', '18 Oct 2026, 01:37:14', 'Zeke (draft only)', 'fields with source lines'], ['Rules checked, 8 of 8 passed', '01:37:50', 'Splash policy engine', 'rule log'], ['Approved', '01:38:06', 'Demo Operator, on their device', 'device signature'], ['Sent from the Payments account', '01:38:09', 'Payments account', 'transaction 5Kq…9fT2'], ['Received by the payout partner', '01:38:12', 'Test payout partner', 'partner confirmation'], ['Paid to UnionBank •••• 9000', '01:38:14', 'PESONet', 'MOCK-PESONET-…6512F659'], ['Proof recorded', '01:38:21', 'Splash evidence service', 'root 0x7c1e…a04b']].map(([a, b, c, d]) => <tr key={String(a)}><td>{a}</td><td className="num">{b}</td><td>{c}</td><td className="mono" style={{ fontSize: 11 }}>{d}</td></tr>)}
              </tbody>
            </table>

            <div style={{ display: 'grid', gridTemplateColumns: 'auto 1fr', gap: 18, marginTop: 24, alignItems: 'center' }} className="block">
              <div className="qr" aria-label="QR code to verify this receipt" />
              <div>
                <strong style={{ fontSize: 14 }}>How to check this receipt</strong>
                <p style={{ marginTop: 4, fontSize: 12.5 }}>Scan, or open <span className="mono">splash.finance/receipt/r_6512f659</span>. Your browser recomputes the payment’s fingerprint and checks it against the proof recorded on 18 Oct 2026. If any field on this page was changed, the check fails. The server supplies the record, never the answer.</p>
                <div className="mono" style={{ fontSize: 10.5, color: 'var(--muted)', marginTop: 6, overflowWrap: 'anywhere' }}>fingerprint 4108828ed413fb558fd8daf9ef484273e699e074a7021f850f692c95c268534c · root 0x7c1e…a04b</div>
              </div>
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, marginTop: 28, paddingTop: 12, borderTop: '1px solid var(--line)', fontSize: 10.5, color: 'var(--muted)' }}>
              <span>Splash is in sandbox and is not yet a licensed money-services business. This receipt describes a simulated payment on a test network.</span><span className="num">Page 1 of 1</span>
            </div>
            <div aria-hidden style={{ position: 'absolute', inset: 0, display: 'grid', placeItems: 'center', pointerEvents: 'none' }}><span style={{ fontSize: 90, fontWeight: 900, color: 'rgb(12 62 72 / .05)', transform: 'rotate(-24deg)', letterSpacing: '.1em' }}>TEST MODE</span></div>
          </article></div>

          <aside style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div className="card">
              <h3 className="card-title">What the auditor link opens</h3>
              <p style={{ fontSize: 13, color: 'var(--text-2)', lineHeight: 1.5 }}>The same page, read-only, with the Verify button live and nothing else from the dashboard: no sidebar, no account. Today’s shared page is the old design (tab “Flaws” in the reply).</p>
              <div style={{ marginTop: 10, display: 'flex', gap: 6, flexWrap: 'wrap' }}><Tag tone="ok">Verify live</Tag><Tag>Read-only</Tag><Tag>Expires in 90 days</Tag></div>
            </div>
            <div className="card">
              <h3 className="card-title">Evidence pack (ZIP) for the accountant</h3>
              <div className="pack" style={{ gridTemplateColumns: '1fr 1fr' }}>
                {[['receipt.pdf', 'this page'], ['invoice-10000.pdf', 'the supplier’s document'], ['approvals.json', 'who, when, which device'], ['proof.json', 'fingerprint, root, how to recompute'], ['bank-advice.txt', 'partner and bank references'], ['README.txt', 'how to verify offline']].map(([f, d]) => <div key={f}><b className="mono" style={{ fontSize: 12 }}>{f}</b>{d}</div>)}
              </div>
            </div>
            <div className="card">
              <h3 className="card-title">Monthly statement, same style</h3>
              <p style={{ fontSize: 13, color: 'var(--text-2)', lineHeight: 1.5 }}>One PDF per month per account: every payment, interest booked, moves between accounts, with the receipt number on each line. The accountant posts from this, not from screenshots.</p>
              <div style={{ marginTop: 10 }}><Tag tone="gold">New in prompt 12</Tag></div>
            </div>
          </aside>
        </div>
      </div>
    </div>
  )
}
