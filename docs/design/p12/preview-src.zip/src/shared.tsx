import type { CSSProperties, ReactNode } from 'react'
import logo from './assets/logo.webp'

export const Card = ({ children, title, right, style, hov, className = '' }: { children: ReactNode; title?: ReactNode; right?: ReactNode; style?: CSSProperties; hov?: boolean; className?: string }) => (
  <section className={`card ${hov ? 'hov' : ''} ${className}`} style={style}>
    {title && <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10, marginBottom: 12 }}><h3 className="card-title" style={{ margin: 0 }}>{title}</h3>{right}</div>}
    {children}
  </section>
)
export const Btn = ({ children, kind = 'quiet', lg, style, onClick }: { children: ReactNode; kind?: string; lg?: boolean; style?: CSSProperties; onClick?: () => void }) => (
  <button type="button" className={`btn ${kind} ${lg ? 'lg' : ''}`} style={style} onClick={onClick}>{children}</button>
)
export const Tag = ({ children, tone = '' }: { children: ReactNode; tone?: string }) => <span className={`tag ${tone}`}>{children}</span>
export const Field = ({ label, ph, icon }: { label: string; ph: string; icon?: string }) => (
  <div className="field"><label>{label}</label><div className="in">{icon && <span aria-hidden style={{ fontSize: 13 }}>{icon}</span>}{ph}</div></div>
)
export const Row = ({ k, v, total }: { k: ReactNode; v: ReactNode; total?: boolean }) => <div className={`row num ${total ? 'total' : ''}`}><span>{k}</span><strong>{v}</strong></div>
export const Check = ({ size = 14 }: { size?: number }) => <svg width={size} height={size} viewBox="0 0 16 16" aria-hidden><path d="M3 8.5l3 3 7-7" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" /></svg>

export const Wordmark = ({ light }: { light?: boolean }) => (
  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 8, fontWeight: 900, fontSize: 19, color: light ? '#F1F8F6' : '#083640', letterSpacing: '-.02em' }}>
    <span style={{ width: 30, height: 30, display: 'grid', placeItems: 'center', background: '#FFFAF4', borderRadius: 9 }}><img src={logo} alt="" width={22} height={21} /></span>Splash
  </span>
)

export const TopNav = () => (
  <div className="topnav">
    <Wordmark />
    <nav aria-label="Landing">
      {[['How it works', '4 steps'], ['Platform', 'Vault + proof'], ['Working capital', 'Supply loop'], ['Routes', 'MY-PH sandbox'], ['Compare', 'Fees + proof'], ['Zeke', 'Prepare + approve']].map(([a, b]) => <span key={a}>{a}<small>{b}</small></span>)}
    </nav>
    <Btn kind="dark">Start sending ↘</Btn>
  </div>
)

/** The landing footer, unchanged on purpose (Sky, 18 Oct): shown so each landing preview ends the way the real page does. */
export const Footer = () => (
  <footer className="footer" style={{ position: 'relative' }}>
    <span className="keep tag">Footer unchanged</span>
    <div className="footer-in">
      <div>
        <div className="fmark"><Wordmark /></div>
        <p style={{ margin: '10px 0 8px', fontSize: 13, fontWeight: 700, color: 'var(--deep)', maxWidth: '30ch' }}>Supplier payments from Malaysia to the Philippines, with proof for the auditor.</p>
        <div className="mono">▣ Sandbox · Solana devnet</div><div className="mono">▣ Settlement on Solana</div><div className="mono">▣ Zeke prepares. You approve.</div>
      </div>
      <div><h4>Product</h4><a>How it works</a><a>Compare</a><a>Platform</a><a>Working capital</a><a>Routes</a></div>
      <div><h4>Trust</h4><a>Trust &amp; compliance</a><a>Zeke control plane</a><a>Log in</a><a>Open payment desk</a></div>
      <div><h4>Compliance</h4><p style={{ fontSize: 12, lineHeight: 1.55, color: 'var(--text-2)' }}>Licence application in preparation with Labuan FSA. Not yet authorised to hold customer funds. USDC moves on Solana from the business's own vault, approved by a person on their device. This build runs on Solana devnet; USD in and local-currency payouts are not live yet.</p></div>
    </div>
    <div className="footer-bar"><span>© 2026 Splash</span><span>Settlement on Solana · Evidence encrypted with Seal, stored on Walrus</span></div>
  </footer>
)

export const SectionHead = ({ kick, title, em, lede, right }: { kick: string; title: string; em?: string; lede?: ReactNode; right?: ReactNode }) => (
  <div className="sec-head">
    <div><span className="kick">{kick}</span><h2 className="disp ink small" style={{ marginTop: 14 }}>{title}{em && <em>{em}</em>}</h2></div>
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12, alignItems: 'flex-start' }}>{lede && <p className="lede">{lede}</p>}{right}</div>
  </div>
)

export const Brief = ({ title, lines }: { title: string; lines: string[] }) => (
  <div className="ph"><strong>New image · {title}</strong>{lines.map(l => <span key={l}>{l}</span>)}</div>
)

export const Note = ({ children }: { children: ReactNode }) => (
  <div style={{ background: '#fff', border: '1px dashed rgb(12 62 72 / .35)', borderRadius: 14, padding: '10px 14px', fontSize: 13, lineHeight: 1.5, color: 'var(--deep)' }}>{children}</div>
)
