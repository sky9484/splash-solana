import { useEffect, useRef, useState } from 'react'
import { Btn, Card, Check, Footer, Note, SectionHead, Tag, TopNav } from './shared'
import { PROMPTS } from './prompts'
import hero from './assets/hero.webp'
import usd from './assets/usd.webp'
import php from './assets/php.webp'
import bridge from './assets/bridge.webp'
import loopsettle from './assets/loopsettle.webp'
import loopsave from './assets/loopsave.webp'
import loopsupply from './assets/loopsupply.webp'
import pools from './assets/pools.webp'
import machine from './assets/machine.webp'
import island from './assets/island.webp'
import quotes from './assets/quotes.webp'
import settle from './assets/settle.webp'
import proof from './assets/proof.webp'
import copilot from './assets/copilot.webp'
import gE1 from './assets/g_e1.webp'
import gE2 from './assets/g_e2.webp'
import gE3 from './assets/g_e3.webp'
import gE4 from './assets/g_e4.webp'
import gA from './assets/g_a.webp'
import gH2 from './assets/g_h2.webp'
import gH3 from './assets/g_h3.webp'
import gH4 from './assets/g_h4.webp'
import gM from './assets/g_m.webp'
import gSea from './assets/g_sea.webp'

const GEN: Record<string, string> = { E1: gE1, E2: gE2, E3: gE3, E4: gE4, A: gA, H2: gH2, H3: gH3, H4: gH4 }

const Ph = ({ id }: { id: string }) => { const p = PROMPTS.find(x => x.id === id)!; return <div className="gen riseIn" style={{ height: 240, width: '100%', maxWidth: 420 }}><b>Image {p.id} · {p.title}</b><span>New image to generate. Prompt in tab 6.</span></div> }
const Gen = ({ id, hero: h }: { id: string; hero?: boolean }) => <img src={GEN[id]} alt="" className={`genimg ${h ? 'hero' : ''}`} />

const FlagMY = () => (<svg viewBox="0 0 28 14" width="34" height="17" aria-hidden><rect width="28" height="14" fill="#fff" />{[0, 2, 4, 6, 8, 10, 12].map(y => <rect key={y} y={y} width="28" height="1" fill="#CC0001" />)}<rect width="14" height="8" fill="#010066" /><circle cx="5.6" cy="4" r="2.6" fill="#FC0" /><circle cx="6.5" cy="4" r="2.2" fill="#010066" /><circle cx="10" cy="4" r="1.2" fill="#FC0" /></svg>)
const FlagPH = () => (<svg viewBox="0 0 28 14" width="34" height="17" aria-hidden><rect width="28" height="7" fill="#0038A8" /><rect y="7" width="28" height="7" fill="#CE1126" /><path d="M0 0 L12 7 L0 14Z" fill="#fff" /><circle cx="4" cy="7" r="1.8" fill="#FCD116" /></svg>)

/* Isometric receipt slab: real demo numbers from the transfer flow, no times, canon fee split. */
function MoneyCard() {
  return (
    <div className="mc-scene" aria-label="Example payment: you send US$5,012.50 from Malaysia, the supplier receives 287,000 pesos in the Philippines">
      <div className="mc">
        <div className="mc-l">You send</div>
        <div className="mc-n num">US$5,012.50</div>
        <div className="mc-f"><FlagMY /><span>From Malaysia<br /><small>your own vault</small></span></div>
        <div className="mc-div"><i>↓</i></div>
        <div className="mc-l">Supplier receives</div>
        <div className="mc-n num">₱287,000.00</div>
        <div className="mc-f"><FlagPH /><span>BDO •••• 4471<br /><small>Philippines</small></span></div>
        <div className="mc-row ok"><span className="mc-ic">✓</span><strong>Delivered to the bank</strong></div>
        <div className="mc-row"><span className="mc-ic fee">$</span><strong>Fees US$12.50</strong><small>Splash US$5.00 + partner at cost</small></div>
        <div className="mc-foot">Receipt SPL-R-0415 · verifies</div>
      </div>
    </div>
  )
}

const BEATS = [
  { k: 'Pay suppliers abroad', t: ['Pay', 'suppliers', 'abroad.'], em: 'Prove every payment.', lede: 'Malaysian businesses pay suppliers in the Philippines from their own account. Delivered to the bank. Proof for the auditor. Splash never holds the money.', cta: true, img: 'island' },
  { k: '01 · An invoice arrives', t: ['Zeke reads', 'the invoice.'], em: 'You check it.', lede: 'Drop a supplier’s invoice. Zeke fills in the payment and shows the line each field came from. It reads with no tools, so a document can’t make it do anything.', img: 'E1' },
  { k: '02 · A person approves', t: ['Zeke drafts.', 'A person approves.'], em: 'On your device.', lede: 'Eight rules run as code before the approval card appears. The quote stays fresh for sixty seconds. Nobody at Splash can press this button.', img: 'E2' },
  { k: '03 · Two routes', t: ['Two routes.', 'Same pesos.'], em: 'You pick.', lede: 'Cheapest or Fastest, ranked by what the supplier receives. Dollars travel as USDC to the payout partner, who pays the bank in pesos.', img: 'E3' },
  { k: '04 · The product', t: ['Payments are', 'the feature.'], em: 'Proof is the product.', lede: 'One receipt: invoice, approval, route, rate and bank reference, with its proof recorded. Verify it in the browser. Change one field and it fails.', cta: true, img: 'E4' },
]

function Story() {
  const ref = useRef<HTMLDivElement>(null)
  const [p, setP] = useState(0)
  useEffect(() => {
    const onScroll = () => { const el = ref.current; if (!el) return; const r = el.getBoundingClientRect(); const total = el.offsetHeight - window.innerHeight; setP(Math.min(1, Math.max(0, -r.top / total))) }
    onScroll(); window.addEventListener('scroll', onScroll, { passive: true }); return () => window.removeEventListener('scroll', onScroll)
  }, [])
  const beat = Math.min(4, Math.floor(p * 5))
  const go = (i: number) => { const el = ref.current; if (!el) return; window.scrollTo({ top: el.offsetTop + (el.offsetHeight - window.innerHeight) * ((i + 0.5) / 5), behavior: 'smooth' }) }
  const vis = (i: number) => (i === beat ? { opacity: 1, transform: 'none' } : { opacity: 0, transform: i < beat ? 'translateY(-22px)' : 'translateY(22px)', pointerEvents: 'none' as const })
  const artVis = (i: number) => (i === beat ? { opacity: 1, transform: 'scale(1)' } : { opacity: 0, transform: i < beat ? 'scale(.92) translateY(-16px)' : 'scale(.92) translateY(16px)', pointerEvents: 'none' as const })
  return (
    <section ref={ref} className="story" aria-label="Hero story">
      <div className="story-pin">
        <div className="progress" aria-hidden><i style={{ width: `${p * 100}%` }} /></div>
        <div className="rail" aria-label="Beats">{BEATS.map((b, i) => <button key={b.k} type="button" aria-current={i === beat ? 'step' : undefined} onClick={() => go(i)}><i />{i === 0 ? 'Start' : b.k.slice(0, 2)}</button>)}</div>
        <div className="story-left">
          {BEATS.map((b, i) => (
            <div key={b.k} className="beat" style={vis(i)}>
              <span className="kick">{b.k}</span>
              <h1 className={`disp ${i ? 'mid' : ''}`}>{b.t.map(l => <span key={l} style={{ display: 'block' }}>{l}</span>)}<em>{b.em}</em></h1>
              <p className="lede">{b.lede}</p>
              {b.cta && <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}><Btn kind="dark" lg>Open payment desk →</Btn><Btn kind="quiet" lg>{i === 0 ? 'See how it works' : 'Verify a sample receipt'}</Btn></div>}
            </div>
          ))}
        </div>
        <div className="story-stage" aria-hidden>
          {BEATS.map((b, i) => (
            <div key={b.k} className="beat-art" style={artVis(i)}>
              {b.img === 'island' ? <img src={hero} alt="" className="stage-island" style={{ position: 'static', transform: 'none', width: 'min(100%,560px)' }} /> : <Gen id={b.img} hero />}
            </div>
          ))}
          <img src={usd} alt="" className="bob" style={{ position: 'absolute', right: '4%', top: '6%', width: 70, opacity: beat === 0 ? 1 : 0, transition: 'opacity .4s' }} />
          <img src={php} alt="" className="bob" style={{ position: 'absolute', left: '2%', bottom: '10%', width: 62, opacity: beat === 0 || beat === 3 ? 1 : 0, transition: 'opacity .4s', animationDelay: '1s' }} />
          {/* the small product cards stay (hidden on phones) */}
          <div className="ui-float" style={{ right: '0', bottom: '6%', width: 250, ...(beat === 1 ? { opacity: 1, transform: 'none' } : { opacity: 0, transform: 'translateY(16px)' }) }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}><strong>Check the invoice</strong><Tag tone="amber">From line 12</Tag></div>
            <div className="row num"><span>Amount</span><strong>₱287,000.00</strong></div><div className="row"><span>Bank</span><strong>BDO •••• 4471</strong></div>
          </div>
          <div className="ui-float" style={{ right: '0', bottom: '6%', width: 250, ...(beat === 2 ? { opacity: 1, transform: 'none' } : { opacity: 0, transform: 'translateY(16px)' }) }}>
            <div className="row"><span>Rules</span><strong style={{ color: 'var(--ok-ink)' }}>8 of 8 pass</strong></div><div className="row num"><span>You pay</span><strong>US$5,012.50</strong></div>
            <button type="button" className="btn approve" style={{ width: '100%', marginTop: 8, minHeight: 40 }}>Approve on this device</button>
          </div>
          <div className="ui-float" style={{ right: '0', bottom: '6%', width: 280, ...(beat === 3 ? { opacity: 1, transform: 'none' } : { opacity: 0, transform: 'translateY(16px)' }) }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', gap: 6, flexWrap: 'wrap' }}><Tag tone="ok">Cheapest · US$12.50</Tag><Tag tone="gold">Fastest · US$19.00</Tag></div>
            <div style={{ position: 'relative', height: 14, marginTop: 10 }}><div className="wire" style={{ left: 4, right: 4, top: 6 }}>{beat === 3 && <><span className="coin" /><span className="coin c2" /></>}</div></div>
          </div>
          <div className="ui-float" style={{ right: '0', bottom: '6%', width: 250, ...(beat === 4 ? { opacity: 1, transform: 'none' } : { opacity: 0, transform: 'translateY(16px)' }) }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}><strong>SPL-R-0415</strong><Tag tone="ok"><Check size={10} /> Verifies</Tag></div>
            <div className="row num"><span>They received</span><strong>₱287,000.00</strong></div><div className="row num"><span>You paid</span><strong>US$5,012.50</strong></div>
          </div>
        </div>
      </div>
    </section>
  )
}

const STEPS = [
  { n: '01', t: 'Your vault', d: 'Your company gets its own Squads vault on Solana. Its keys are made in your browser, and no Splash key can move the money.', art: 'A', stat: 'Squads, on Solana' },
  { n: '02', t: 'Best route by pesos received', d: 'Two routes, ranked by what the supplier receives. Every fee is on the card before you approve.', art: 'H2', stat: 'Cheapest · Fastest' },
  { n: '03', t: 'A person approves', d: 'One approval on your device. You don’t need SOL. A payout partner then pays the supplier’s bank in pesos.', art: 'H3', stat: 'Approve on this device' },
  { n: '04', t: 'Proof saved', d: 'The receipt is recorded with its proof. Verify it in any browser; change one field and it fails.', art: 'H4', stat: 'This receipt verifies' },
]

const CMP: string[][] = [
  ['Who holds the money', 'The bank', 'The broker', 'The platform', 'Your own vault'],
  ['Fee', '3–5% typical', '2–4% typical', '0.5–1.5%', '0.10% + US$2 min'],
  ['Rate', 'In the markup', 'In the spread', 'Mid-market + fee', 'On the card first'],
  ['Supplier bank check', 'None', 'Varies', 'Name check', 'Call-back'],
  ['Approval', 'Bank login', 'Email or phone', 'User login', 'Approver’s device'],
  ['Batch', 'Bank file', 'Manual', 'Batch tool', 'One file, one approval'],
  ['Receipt', 'Bank advice', 'Email', 'History export', 'Verifies itself'],
  ['Idle cash', 'Deposit', '—', '—', 'Reserve + T-bill pool'],
]


/* Phones: no pinned scroll. A hero block, then the four beats as swipe cards with small art. */
function MobileStory() {
  const rail = useRef<HTMLDivElement>(null)
  const [at, setAt] = useState(0)
  const steps = BEATS.slice(1)
  const onScroll = () => { const el = rail.current; if (!el) return; const w = (el.firstElementChild as HTMLElement | null)?.offsetWidth ?? 1; setAt(Math.round(el.scrollLeft / (w + 12))) }
  const goTo = (i: number) => { const el = rail.current; if (!el) return; const w = (el.firstElementChild as HTMLElement | null)?.offsetWidth ?? 0; el.scrollTo({ left: i * (w + 12), behavior: 'smooth' }) }
  const b0 = BEATS[0]
  return (
    <section className="mstory" aria-label="Hero">
      <div className="m-hero">
        <span className="kick">{b0.k}</span>
        <h1 className="disp m-h">{b0.t.map(l => <span key={l} style={{ display: 'block' }}>{l}</span>)}<em>{b0.em}</em></h1>
        <p className="lede">{b0.lede}</p>
        <div className="m-cta"><Btn kind="dark" lg>Open payment desk →</Btn><Btn kind="quiet" lg>See how it works</Btn></div>
        <img src={hero} alt="" className="m-island" />
      </div>
      <div className="m-railhead"><strong>How a payment goes</strong><span>{at + 1} / {steps.length}</span></div>
      <div className="m-rail" ref={rail} onScroll={onScroll}>
        {steps.map(b => (
          <article key={b.k} className="m-card">
            <img src={GEN[b.img]} alt="" />
            <span className="kick">{b.k}</span>
            <h2 className="m-ct">{b.t.join(' ')} <em>{b.em}</em></h2>
            <p>{b.lede}</p>
            {b.cta && <Btn kind="quiet">Verify a sample receipt</Btn>}
          </article>
        ))}
      </div>
      <div className="m-dots" role="tablist" aria-label="Steps">{steps.map((b, i) => <button key={b.k} type="button" role="tab" aria-selected={i === at} aria-label={b.k} onClick={() => goTo(i)} />)}</div>
    </section>
  )
}

export default function Landing() {
  const [step, setStep] = useState(0)
  const s = STEPS[step]
  return (
    <div className="stage">
      <div className="wrap"><TopNav /></div>
      <div className="wrap"><Note><strong>The whole landing on Paper.</strong> Desktop keeps the pinned five-beat story with your images E1–E4. Phones get their own layout: the hero, then the four steps as swipe cards with small art. How it works 01–04 now use images A and H2–H4. The closing band uses your generated payment card M.</Note></div>

      <Story />
      <MobileStory />

      {/* THE THREE LOOPS */}
      <section className="sec wrap">
        <SectionHead kick="The three loops" title="Move it. Keep it." em="Finance it." lede="USDC on Solana already moves. Splash’s job is what the transfer alone can’t do: reach the supplier’s bank, keep the money in your own vault, and turn invoices into working capital." />
        <div className="g3">
          {[
            { n: '01', k: 'Settle', live: true, t: 'Pay the supplier’s bank.', d: 'Pay suppliers in the Philippines in USDC on Solana. Every approved payout builds verified counterparties and settlement history.', art: loopsettle, foot: 'USDC → PHP · sandbox' },
            { n: '02', k: 'Keep', live: true, t: 'Keep it in your vault.', d: 'Money waits in your business’s own Squads vault. No Splash key can move it, and a person approves every payment out.', art: loopsave, foot: 'Your vault · human-approved' },
            { n: '03', k: 'Supply', live: false, t: 'Finance it, later.', d: 'Invoices would become working capital: your buyer funds early payment against a receivable both sides can verify.', art: loopsupply, foot: 'Buyer-funded · no third-party lender' },
          ].map(c => (
            <Card key={c.n} hov>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}><span className="mchip" style={{ background: 'rgb(12 62 72 / .07)', color: 'var(--deep)' }}>{c.n} · {c.k}</span>{c.live ? <Tag tone="ok">● Live</Tag> : <Tag tone="coral">Roadmap</Tag>}</div>
              <div className="art-box"><img src={c.art} alt="" /></div>
              <h3 style={{ fontSize: 20, fontWeight: 800, color: 'var(--deep)' }}>{c.t}</h3>
              <p style={{ fontSize: 13.5, lineHeight: 1.55, color: 'var(--text-2)', margin: '8px 0 12px' }}>{c.d}</p>
              <span className="mchip" style={{ background: 'rgb(12 62 72 / .07)', color: 'var(--deep)' }}>{c.foot}</span>
            </Card>
          ))}
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', gap: 16, marginTop: 18, flexWrap: 'wrap', alignItems: 'center' }}>
          <p style={{ fontSize: 13, color: 'var(--on-page-2)', maxWidth: '60ch' }}><strong>Where the fees live:</strong> Splash’s fee payer covers the Solana network fees, so you don’t need SOL. Splash charges 0.10% per payout (US$2 minimum); the payout partner’s fee is shown before you approve.</p>
          <Btn kind="dark">Explore the Supply loop →</Btn>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section className="sec wrap" style={{ paddingTop: 0 }}>
        <div className="cyan" style={{ padding: 36 }}>
          <div className="steps">
            <div>
              <span className="kick" style={{ color: 'var(--on-cyan-2)' }}>How it works</span>
              <h2 className="disp" style={{ fontSize: 'clamp(40px,5vw,72px)', margin: '14px 0 22px', textShadow: '2px 2px 0 #083640,4px 4px 0 #083640,6px 6px 0 #083640', WebkitTextStroke: '0' }}>Four steps.<em style={{ textShadow: '2px 2px 0 #c49646,4px 4px 0 #c49646,6px 6px 0 #083640' }}>One record.</em></h2>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>{STEPS.map((x, i) => <button key={x.n} type="button" className="stepbtn" aria-current={i === step} onClick={() => setStep(i)}><b>{x.n}</b>{x.t}<span style={{ marginLeft: 'auto', opacity: .6 }}>›</span></button>)}</div>
            </div>
            <div className="card" style={{ padding: 20, display: 'flex', flexDirection: 'column', gap: 14, minHeight: 420 }}>
              <div style={{ display: 'flex', justifyContent: 'flex-end' }}><Tag tone="gold">Current checkpoint · {s.stat}</Tag></div>
              <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: 240 }}><div style={{ width: '100%', maxWidth: 440 }} className="riseIn" key={s.n}><img src={GEN[s.art]} alt="" className="howimg" /></div></div>
              <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start', borderTop: '1px solid var(--line)', paddingTop: 12 }}><span className="mchip" style={{ background: 'var(--gold)', color: 'var(--deep)' }}>{s.n}</span><div><strong style={{ fontSize: 16, color: 'var(--deep)' }}>{s.t}</strong><p style={{ fontSize: 13.5, color: 'var(--text-2)', marginTop: 4 }}>{s.d}</p></div></div>
            </div>
          </div>
        </div>
      </section>

      {/* THE PLATFORM */}
      <section className="sec wrap" style={{ paddingTop: 0 }}>
        <SectionHead kick="The platform" title="Everything between invoice" em="and settlement." lede="One approval-gated desk for your vault, your suppliers’ payouts and the proof. Everything runs in the sandbox until a payout partner is live." />
        <div className="g3">
          {[
            { n: '01', k: 'Vault', t: 'Your money stays yours.', d: 'Money sits in your business’s own Squads vault. No Splash key can move it.', art: pools, foot: 'Your vault · your approval' },
            { n: '02', k: 'Settlement', t: 'Transfer and fee, one transaction.', d: 'A payment’s transfer and Splash’s fee land together, or nothing moves. A batch goes in chunks, and each chunk pays all its suppliers or none.', art: machine, foot: 'USDC on Solana · you don’t need SOL' },
            { n: '03', k: 'Approval', t: 'Zeke drafts. A person approves.', d: 'Zeke drafts payments and batches. It cannot sign or send. A person approves each payment with their device key.', art: island, foot: 'Device key · human approval' },
          ].map(c => (
            <Card key={c.n} hov>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}><span className="mchip" style={{ background: 'rgb(12 62 72 / .07)', color: 'var(--deep)' }}>{c.n}</span><span className="mchip" style={{ background: 'rgb(12 62 72 / .07)', color: 'var(--deep)' }}>{c.k}</span></div>
              <div className="art-box"><img src={c.art} alt="" /></div>
              <h3 style={{ fontSize: 20, fontWeight: 800, color: 'var(--deep)' }}>{c.t}</h3>
              <p style={{ fontSize: 13.5, lineHeight: 1.55, color: 'var(--text-2)', margin: '8px 0 12px' }}>{c.d}</p>
              <span className="mchip" style={{ background: 'rgb(12 62 72 / .07)', color: 'var(--deep)' }}>{c.foot}</span>
            </Card>
          ))}
        </div>
      </section>

      {/* ROUTES: image on the page, dark tiles that pop */}
      <section className="sec wrap" style={{ paddingTop: 0 }}>
        <div className="sec-head" style={{ alignItems: 'center', marginBottom: 18 }}>
          <div>
            <span className="kick">Routes · the first corridor</span>
            <h2 className="disp ink small" style={{ marginTop: 14 }}>USDC in.<em>Pesos out.</em></h2>
            <p className="lede" style={{ marginTop: 18 }}>Malaysia to the Philippines is the sandbox corridor. Indonesia follows when a payout partner and the controls are ready.</p>
            <div style={{ display: 'flex', gap: 8, margin: '16px 0' }}><Tag tone="ink">PHP · sandbox</Tag><Tag>IDR · next</Tag><Tag>VND · later</Tag></div>
            <Btn kind="dark">Open the payout desk →</Btn>
          </div>
          <img src={bridge} alt="" style={{ width: '100%', maxWidth: 620, justifySelf: 'end' }} className="bob" />
        </div>
        <div className="rtiles">
          {[['They receive', '₱287,000.00', 'The full invoice amount. The supplier never pays a landing fee.'], ['You pay', 'US$5,012.50', 'Converted amount plus a 0.25% all-in fee, shown before you approve.'], ['Rate', '57.40', 'Locked for 60 seconds at approval. Test rate in the sandbox.'], ['Paid out by', 'PESONet', 'Any Philippine bank. InstaPay for smaller amounts.']].map(([k, v, m]) => (
            <div key={k} className="rtile" tabIndex={0}><div className="lbl">{k}</div><div className="v num">{v}</div><div className="more">{m}</div></div>
          ))}
        </div>
      </section>

      {/* REGION: where Splash is built to run (honest corridor status) */}
      <section className="sec wrap" style={{ paddingTop: 0 }}>
        <div className="region">
          <div>
            <span className="kick">Southeast Asia</span>
            <h2 className="h-clean" style={{ margin: '12px 0 12px', color: 'var(--deep)' }}>Built for the trade between <em>our neighbours.</em></h2>
            <p className="lede">Malaysian businesses buy from across the region. Splash starts where the volume is and adds a corridor only when a licensed payout partner is signed for it.</p>
            <div className="corr">
              <div className="corr-row now"><span>MY → PH</span><strong>Sandbox today</strong></div>
              {['MY → ID', 'MY → TH', 'MY → VN', 'MY → SG'].map(c => <div key={c} className="corr-row"><span>{c}</span><strong>Roadmap</strong></div>)}
            </div>
          </div>
          <img src={gSea} alt="Isometric map of Southeast Asian landmarks linked by payment routes" className="region-img" />
        </div>
      </section>

      {/* COMPARISON */}
      <section className="sec wrap" style={{ paddingTop: 0 }}>
        <SectionHead kick="Comparison" title="Built for business." em="Designed to move." lede="Splash charges when a payout leaves for a supplier’s bank, shows every fee before you approve, and keeps one record per payment." />
        <table className="cmp" style={{ tableLayout: 'fixed' }}>
          <thead><tr><th style={{ width: '22%' }}>&nbsp;</th><th>Bank wire</th><th>Broker / remitter</th><th>Other B2B platforms</th><th className="sp">Splash</th></tr></thead>
          <tbody>{CMP.map(([q, a, b, c, d]) => <tr key={q}><td>{q}</td><td>{a}</td><td>{b}</td><td>{c}</td><td className="sp">{d}</td></tr>)}</tbody>
        </table>
        <p style={{ fontSize: 12, color: 'var(--on-page-2)', marginTop: 12, maxWidth: '80ch' }}>Typical published ranges, not quotes. Splash is in sandbox; no real money moves. Treasury is in test mode until legal sign-off.</p>
      </section>

      {/* ZEKE strip (kept short) */}
      <section className="sec wrap" style={{ paddingTop: 0 }}>
        <div className="g2" style={{ alignItems: 'center' }}>
          <Card style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: 300 }}><img src={copilot} alt="" style={{ maxHeight: 260 }} /></Card>
          <div><span className="kick">Zeke</span><h2 className="disp ink small" style={{ marginTop: 14 }}>Zeke prepares.<em>You approve.</em></h2><p className="lede" style={{ marginTop: 16 }}>Zeke reads invoices, explains routes and checks the rules. It cannot sign or send; a person approves each payment with their device key.</p><div style={{ display: 'flex', gap: 8, marginTop: 14, flexWrap: 'wrap' }}>{['Reader', 'Router', 'Checker', 'Auditor'].map(t => <Tag key={t}>{t}</Tag>)}</div></div>
        </div>
      </section>

      {/* CLOSING BAND */}
      <section className="sec wrap" style={{ paddingTop: 0 }}>
        <div className="cyan close-band" style={{ padding: 36 }}>
          <div><span className="kick" style={{ color: 'var(--on-cyan-2)' }}>Move money better</span><h2 className="disp" style={{ fontSize: 'clamp(36px,4.6vw,66px)', margin: '14px 0 12px', WebkitTextStroke: 0, textShadow: '2px 2px 0 #083640,4px 4px 0 #083640' }}>Pay the supplier.<em style={{ textShadow: '2px 2px 0 #c49646,4px 4px 0 #c49646,6px 6px 0 #083640' }}>Keep the proof.</em></h2><p style={{ fontSize: 14, color: 'var(--on-cyan-2)', maxWidth: '50ch' }}>Start in the sandbox: your own vault, a test payout partner, and a record for every payment.</p><div style={{ display: 'flex', gap: 8, marginTop: 16, flexWrap: 'wrap' }}><Btn kind="gold" lg>Start sending →</Btn><Btn kind="ghost" lg>Log in</Btn></div></div>
          <div className="mcard-img"><img src={gM} alt="Example payment card: you send US$5,012.50 from Malaysia, the supplier receives PHP 287,000.00 in the Philippines, delivered to the bank, fees US$12.50, receipt verifies" /></div>
        </div>
      </section>
      <Footer />
    </div>
  )
}
