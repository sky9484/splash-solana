import { useEffect, useState } from 'react'
import Landing from './landing'
import Auth from './auth'
import WorkingCapital from './wc'
import Track from './track'
import Receipt from './receipt'
import PromptsTab from './promptsTab'

const TABS = [
  ['1', 'Landing page', 'All sections, one scroll', Landing],
  ['2', 'Sign in · Sign up · Forgot · Loading', 'Auth pages + loader', Auth],
  ['3', 'Working capital page', 'Clean type, fintech standard', WorkingCapital],
  ['4', 'Transfer step 5', 'Receipt card + Share with auditor', Track],
  ['5', 'Auditor receipt', 'The PDF / shared page', Receipt],
  ['6', 'Image prompts', 'Grok Imagine / Gemini, 8 images', PromptsTab],
] as const

// Sky, 18 Oct: sign-in and admin pages use Pale; landing, working capital and dashboard use Paper.
const THEME_FOR_TAB = ['paper', 'pale', 'paper', 'paper', 'paper', 'paper'] as const

export default function App() {
  const [i, setI] = useState(0)
  useEffect(() => { window.scrollTo({ top: 0 }) }, [i])
  const View = TABS[i][3]
  const th = THEME_FOR_TAB[i]
  return (
    <>
      <div className="chrome">
        <div className="chrome-in">
          <span className="chrome-title">Splash · final preview</span>
          <span className="chrome-bg"><i style={{ background: th === 'pale' ? '#EFF4F3' : '#FFFAF4' }} />{th === 'pale' ? 'Pale page' : 'Paper page'}</span>
          <div className="tabs" role="tablist" aria-label="Previews">
            {TABS.map(([n, t, s], k) => <button key={n} role="tab" aria-selected={i === k} onClick={() => setI(k)}><span>{n} · {s}</span><span>{t}</span></button>)}
          </div>
        </div>
      </div>
      <div className={`th-${th}`}><View key={i} /></div>
    </>
  )
}
